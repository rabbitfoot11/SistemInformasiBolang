<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bolang</title>
    <style>
        html,
        body {
            width: 100%;
            height: 100%;
        }

        html {
            display: table;
        }

        body {
            display: table-cell;
            vertical-align: middle;
            text-align: center;
        }
    </style>
</head>
<body>
    <img src="bg.png" alt="Trulli" width="500">
</body>
</html><?php /**PATH C:\xampp\htdocs\bolang\resources\views/welcome.blade.php ENDPATH**/ ?>