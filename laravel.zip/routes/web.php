<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/aceh', function () {
    return view('welcome');
});

Route::get('/sumaterautara', function () {
    return view('welcome');
});

Route::get('/sumateraselatan', function () {
    return view('welcome');
});

Route::get('/sumaterabarat', function () {
    return view('welcome');
});

Route::get('/bengkulu', function () {
    return view('welcome');
});

Route::get('/riau', function () {
    return view('welcome');
});

Route::get('/kepulauanriau', function () {
    return view('welcome');
});

Route::get('/jambi', function () {
    return view('welcome');
});

Route::get('/lampung', function () {
    return view('welcome');
});

Route::get('/bangkabelitung', function () {
    return view('welcome');
});

Route::get('/kalimantanbarat', function () {
    return view('welcome');
});

Route::get('/kalimantantimur', function () {
    return view('welcome');
});

Route::get('/kalimantanselatan', function () {
    return view('welcome');
});

Route::get('/kalimantantengah', function () {
    return view('welcome');
});

Route::get('/kalimantanutara', function () {
    return view('welcome');
});

Route::get('/banten', function () {
    return view('welcome');
});

Route::get('/jakarta', function () {
    return view('welcome');
});

Route::get('/jawabarat', function () {
    return view('welcome');
});

Route::get('/jawatengah', function () {
    return view('welcome');
});

Route::get('/yogyakarta', function () {
    return view('welcome');
});

Route::get('/jawatimur', function () {
    return view('welcome');
});

Route::get('/bali', function () {
    return view('welcome');
});

Route::get('/nusatenggaratimur', function () {
    return view('welcome');
});

Route::get('/nusatenggarabarat', function () {
    return view('welcome');
});

Route::get('/gorontalo', function () {
    return view('welcome');
});

Route::get('/sulawesibarat', function () {
    return view('welcome');
});

Route::get('/sulawesitengah', function () {
    return view('welcome');
});

Route::get('/sulawesiutara', function () {
    return view('welcome');
});

Route::get('/sulawesitenggara', function () {
    return view('welcome');
});

Route::get('/sulawesiselatan', function () {
    return view('welcome');
});

Route::get('/malukuutara', function () {
    return view('welcome');
});

Route::get('/maluku', function () {
    return view('welcome');
});

Route::get('/papuabarat', function () {
    return view('welcome');
});

Route::get('/papua', function () {
    return view('welcome');
});

Route::get('/papuaselatan', function () {
    return view('welcome');
});

Route::get('/papuatengah', function () {
    return view('welcome');
});

Route::get('/papuapegunungan', function () {
    return view('welcome');
});